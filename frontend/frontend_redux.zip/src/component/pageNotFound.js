const PageNotFound = () => {
  return (
    <>
      <h3>page not found</h3>
    </>
  )
}
export default PageNotFound
