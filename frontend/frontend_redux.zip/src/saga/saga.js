import { call, put, takeEvery } from "redux-saga/effects"

import {
  ADD_USER,
  ALL_USER,
  EDIT_USER,
  GET_USER,
  LOGIN_DATA,
  LOGIN_USER,
  NEW_REQUEST,
  OPEN_REQUEST,
  PROFILE_USER,
  REQUEST_RELEASED,
  REQUEST_SENDED,
  RE_NEW_REQUEST,
  SEND_REQUEST,
  UPDATE_USER,
  USERS_DATA,
  USER_ADD,
  USER_PROFILE,
  USER_UPDATED,
  VIEW_ALL_USER,
  VIEW_USERS,
} from "../constants/constants"

function* addUser(data) {
  try {
    let response = yield fetch("http://localhost:4002/user/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data.data),
    })
    response = yield response.json()
    console.log("response", response)
    yield put({
      type: USER_ADD,
      data: response,
    })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* fetchUser() {
  try {
    // const user = yield call(Api.fetchUser, action.payload.userId)
    let response = yield fetch("http://localhost:4002/user/getAll")
    response = yield response.json()

    yield put({ type: VIEW_ALL_USER, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* loginUser(data) {
  try {
    console.log("saga", data)
    // const user = yield call(Api.fetchUser, action.payload.userId)
    let response = yield fetch("http://localhost:4002/user/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data.data),
    })
    response = yield response.json()
    console.log("response login", response)
    yield put({ type: LOGIN_USER, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* allUser(pagingData) {
  try {
    console.log("pagingData", pagingData)
    const pageSize = pagingData?.data?.pageSize
    const pageNo = pagingData?.data?.pageNo
    const search = pagingData?.data?.search
    const order = pagingData?.data?.order

    console.log("pagesize", pageSize, pageNo)

    let id = JSON.parse(localStorage.getItem("data"))
    console.log("saga", id._id)
    id = id._id
    // const user = yield call(Api.fetchUser, action.payload.userId)
    let response = yield fetch(
      `http://localhost:4002/user/userAlldata/${id}?pageSize=${pageSize}&page=${pageNo}&asc=${order}&search=${search}`,
      {
        headers: {
          // authorization:JSON.parse(localStorage.getItem('token'))
          authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
        },
      }
    )
    response = yield response.json()
    console.log("response", response)
    if (response.data) {
      let res =
        response.data &&
        response.data.map((allData) => {
          return Object.assign(allData, { action_id: allData._id })
        })
      console.log("response11222", res)
      const result = {
        data: res,
        page: response.page,
        pageSize: response.pageSize,
        profile: response.profile,
        status: response.status,
        total: response.total,
      }
      yield put({ type: ALL_USER, data: result })
    } else {
      yield put({ type: ALL_USER, data: response })
    }
  } catch (err) {
    yield put({ type: "USER_FETCH_FAILED", message: err.message })
  }
}
function* profile() {
  try {
    let id = JSON.parse(localStorage.getItem("data"))
    let data = JSON.parse(localStorage.getItem("data"))
    console.log("role", data)
    console.log("saga", id._id)
    id = id._id
    const role = data.role
    let response = yield fetch(
      `http://localhost:4002/user/userProfile/${id}?role=${role}`,
      {
        headers: {
          // authorization:JSON.parse(localStorage.getItem('token'))
          authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
        },
      }
    )
    response = yield response.json()
    console.log("response login", response)
    yield put({ type: PROFILE_USER, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* user(id) {
  try {
    console.log("saga", id)
    id = id.data

    let response = yield fetch(`http://localhost:4002/user/userEdit/${id}`, {
      headers: {
        // authorization:JSON.parse(localStorage.getItem('token'))
        authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
      },
    })
    response = yield response.json()
    console.log("response login", response)
    yield put({ type: GET_USER, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* updateUser(userData) {
  try {
    const id = userData.data.id
    const data = userData.data.userData
    console.log("userData", id, data)
    let response = yield fetch(`http://localhost:4002/user/userEdit/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
      },
      body: JSON.stringify(data),
    })
    response = yield response.json()

    yield put({ type: USER_UPDATED, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* sendRequest(requestData) {
  try {
    console.log("requestData", requestData.data)
    let response = yield fetch(`http://localhost:4002/user/request/release`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
      },
      body: JSON.stringify(requestData.data),
    })
    response = yield response.json()
    console.log("response login", response)
    yield put({ type: REQUEST_SENDED, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}

function* realeseRequest(releaseData) {
  try {
    console.log("releaseData", releaseData.data)
    let response = yield fetch(`http://localhost:4002/user/realeasesUser`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
      },
      body: JSON.stringify(releaseData.data),
    })
    response = yield response.json()
    console.log("response login", response)
    yield put({ type: REQUEST_RELEASED, data: response })
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}

function* sendForRenewRequest(renewData) {
  try {
    console.log("releaseData", renewData)
    const id = renewData.data.id
    const role = renewData.data.role

    let response = yield fetch(
      `http://localhost:4002/user/delete/realeasesUser/${id}?role=${role}`,
      {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          authorization: `bearer ${JSON.parse(localStorage.getItem("token"))}`,
        },
      }
    )
    response = yield response.json()
    console.log("response login", response)
    yield put({ type: OPEN_REQUEST, data: response })
    // open renew request successfully
  } catch (e) {
    yield put({ type: "USER_FETCH_FAILED", message: e.message })
  }
}
function* sagaUser() {
  yield takeEvery(VIEW_USERS, fetchUser)
  yield takeEvery(ADD_USER, addUser)
  yield takeEvery(LOGIN_DATA, loginUser)
  yield takeEvery(USERS_DATA, allUser)
  yield takeEvery(USER_PROFILE, profile)
  yield takeEvery(EDIT_USER, user)
  yield takeEvery(UPDATE_USER, updateUser)
  yield takeEvery(SEND_REQUEST, sendRequest)
  yield takeEvery(NEW_REQUEST, realeseRequest)
  yield takeEvery(RE_NEW_REQUEST, sendForRenewRequest)
}
export default sagaUser
