import {
  ADD_USER,
  ALL_USER,
  GET_USER,
  LOGIN_USER,
  LOGOUT,
  OPEN_REQUEST,
  PROFILE_USER,
  REQUEST_RELEASED,
  REQUEST_SENDED,
  USER_ADD,
  USER_UPDATED,
  VIEW_ALL_USER,
  VIEW_USERS,
} from "../constants/constants"
let InitialData = {
  view: [],
  profile: [],
  releaseMessage: [],
  openRequestMessage: [],
}

export const usersData = (state = InitialData, action) => {
  if (action.type === USER_ADD) {
    console.log("dataaa", action.data)
    return { ...state, view: action.data }
  }
  if (action.type === VIEW_ALL_USER) {
    console.log("dataaa", action.data)
    return { ...state, view: action?.data?.data }
  }
  if (action.type === LOGIN_USER) {
    console.log("dataaa", action.data)
    return { ...state, view: action?.data }
  }
  if (action.type === ALL_USER) {
    return { ...state, view: action?.data }
  }
  if (action.type === PROFILE_USER) {
    return { ...state, profile: action?.data }
  }
  if (action.type === GET_USER) {
    console.log("aluser", action.data)
    return { ...state, view: action?.data }
  }
  if (action.type === USER_UPDATED) {
    console.log("aluser", action.data)
    return { ...state, view: action?.data }
  }
  if (action.type === REQUEST_SENDED) {
    console.log("aluser", action.data)
    return { ...state, view: action?.data }
  }
  if (action.type === REQUEST_RELEASED) {
    console.log("aluser", action.data)
    return { ...state, releaseMessage: action?.data }
  }
  if (action.type === OPEN_REQUEST) {
    console.log("aluser", action.data)
    return { ...state, openRequestMessage: action?.data }
  }

  // if (action.type === LOGOUT) {
  //   console.log("InitialData", InitialData)
  //   return (state = InitialData)
  // }
  //   } else if (action.type === "REMOVE_TODO") {
  //     return tasks.filter((task) => task !== action.task)
  //   }
  return state
}
