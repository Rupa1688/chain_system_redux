import {
  NEW_REQUEST,
  RE_NEW_REQUEST,
  SEND_REQUEST,
  SHARE_MARKET,
} from "../constants/constants"
export const sendRequest = (data, e) => {
  e.preventDefault()
  console.log("data", data)
  return {
    type: SEND_REQUEST,
    data,
  }
}
export const newRequest = (data, e) => {
  e.preventDefault()
  console.log("newRequest", data)
  return {
    type: NEW_REQUEST,
    data,
  }
}

export const renewRequest = (id, role, e) => {
  e.preventDefault()
  console.log("renewRequest", id)
  return {
    type: RE_NEW_REQUEST,
    data: {
      id,
      role,
    },
  }
}
export const shareMarket = (user, org, e) => {
  e.preventDefault()
  console.log("sdata", user)
  return {
    type: SHARE_MARKET,
    data: {
      user,
      org,
    },
  }
}
